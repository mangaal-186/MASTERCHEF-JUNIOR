1 lb. dried elbow pasta
1/2 cup unsalted butter
1/2 cup all purpose flour
1 1/2 cups whole milk
2 1/2 cups half and half
4 cups grated medium sharp cheddar cheese - divided (measured after grating)
2 cups grated Gruyere cheese - divided (measured after grating)
1/2 Tbsp. salt
1/2 tsp. black pepper
1/4 tsp. paprika